// +------------------------------------------------------------------+
// |             ____ _               _        __  __ _  __           |
// |            / ___| |__   ___  ___| | __   |  \/  | |/ /           |
// |           | |   | '_ \ / _ \/ __| |/ /   | |\/| | ' /            |
// |           | |___| | | |  __/ (__|   <    | |  | | . \            |
// |            \____|_| |_|\___|\___|_|\_\___|_|  |_|_|\_\           |
// |                                                                  |
// | Copyright Mathias Kettner 2014             mk@mathias-kettner.de |
// +------------------------------------------------------------------+
//
// This file is part of Check_MK.
// The official homepage is at http://mathias-kettner.de/check_mk.
//
// check_mk is free software;  you can redistribute it and/or modify it
// under the  terms of the  GNU General Public License  as published by
// the Free Software Foundation in version 2.  check_mk is  distributed
// in the hope that it will be useful, but WITHOUT ANY WARRANTY;  with-
// out even the implied warranty of  MERCHANTABILITY  or  FITNESS FOR A
// PARTICULAR PURPOSE. See the  GNU General Public License for more de-
// ails.  You should have  received  a copy of the  GNU  General Public
// License along with GNU Make; see the file  COPYING.  If  not,  write
// to the Free Software Foundation, Inc., 51 Franklin St,  Fifth Floor,
// Boston, MA 02110-1301 USA.

#include "TableLog.h"
#include <stdint.h>
#include <time.h>
#include <map>
#include <utility>
#include "LogCache.h"
#include "LogEntry.h"
#include "Logfile.h"
#include "OffsetIntColumn.h"
#include "OffsetStringColumn.h"
#include "OffsetTimeColumn.h"
#include "Query.h"
#include "TableCommands.h"
#include "TableContacts.h"
#include "TableHosts.h"
#include "TableServices.h"
#include "mk/Mutex.h"

#ifndef CMC
#include "auth.h"
#endif

using mk::lock_guard;
using mk::mutex;
using std::string;

#define CHECK_MEM_CYCLE 1000 /* Check memory every N'th new message */

TableLog::TableLog(LogCache *log_cache) : _log_cache(log_cache) {
    addColumns(this, "", -1);
}

// static
void TableLog::addColumns(Table *table, string prefix, int indirect_offset,
                          bool add_host, bool add_services) {
    LogEntry *ref = nullptr;
    table->addColumn(new OffsetTimeColumn(
        prefix + "time", "Time of the log event (UNIX timestamp)",
        reinterpret_cast<char *>(&(ref->_time)) - reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetIntColumn(
        prefix + "lineno", "The number of the line in the log file",
        reinterpret_cast<char *>(&(ref->_lineno)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetIntColumn(
        prefix + "class",
        "The class of the message as integer (0:info, 1:state, 2:program, "
        "3:notification, 4:passive, 5:command)",
        reinterpret_cast<char *>(&(ref->_logclass)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetStringColumn(
        prefix + "message", "The complete message line including the timestamp",
        reinterpret_cast<char *>(&(ref->_complete)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetStringColumn(
        prefix + "type",
        "The type of the message (text before the colon), the message itself "
        "for info messages",
        reinterpret_cast<char *>(&(ref->_text)) - reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetStringColumn(
        prefix + "options", "The part of the message after the ':'",
        reinterpret_cast<char *>(&(ref->_options)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetStringColumn(
        prefix + "comment", "A comment field used in various message types",
        reinterpret_cast<char *>(&(ref->_comment)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetStringColumn(
        prefix + "plugin_output",
        "The output of the check, if any is associated with the message",
        reinterpret_cast<char *>(&(ref->_check_output)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetIntColumn(
        prefix + "state", "The state of the host or service in question",
        reinterpret_cast<char *>(&(ref->_state)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetStringColumn(
        prefix + "state_type",
        "The type of the state (varies on different log classes)",
        reinterpret_cast<char *>(&(ref->_state_type)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetIntColumn(
        prefix + "attempt", "The number of the check attempt",
        reinterpret_cast<char *>(&(ref->_attempt)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetStringColumn(
        prefix + "service_description",
        "The description of the service log entry is about (might be empty)",
        reinterpret_cast<char *>(&(ref->_svc_desc)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetStringColumn(
        prefix + "host_name",
        "The name of the host the log entry is about (might be empty)",
        reinterpret_cast<char *>(&(ref->_host_name)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetStringColumn(
        prefix + "contact_name",
        "The name of the contact the log entry is about (might be empty)",
        reinterpret_cast<char *>(&(ref->_contact_name)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));
    table->addColumn(new OffsetStringColumn(
        prefix + "command_name",
        "The name of the command of the log entry (e.g. for notifications)",
        reinterpret_cast<char *>(&(ref->_command_name)) -
            reinterpret_cast<char *>(ref),
        indirect_offset));

    // join host and service tables
    if (add_host) {
        TableHosts::addColumns(table, "current_host_",
                               reinterpret_cast<char *>(&(ref->_host)) -
                                   reinterpret_cast<char *>(ref));
    }
    if (add_services) {
        TableServices::addColumns(table, "current_service_",
                                  reinterpret_cast<char *>(&(ref->_service)) -
                                      reinterpret_cast<char *>(ref),
                                  false /* no hosts table */);
    }
    TableContacts::addColumns(table, "current_contact_",
                              reinterpret_cast<char *>(&(ref->_contact)) -
                                  reinterpret_cast<char *>(ref));
    TableCommands::addColumns(table, "current_command_",
                              reinterpret_cast<char *>(&(ref->_command)) -
                                  reinterpret_cast<char *>(ref));
}

void TableLog::answerQuery(Query *query) {
    lock_guard<mutex> lg(_log_cache->_lock);
    _log_cache->logCachePreChecks();

    int since = 0;
    int until = time(nullptr) + 1;
    // Optimize time interval for the query. In log querys
    // there should always be a time range in form of one
    // or two filter expressions over time. We use that
    // to limit the number of logfiles we need to scan and
    // to find the optimal entry point into the logfile
    query->findIntLimits("time", &since, &until);

    // The second optimization is for log message types.
    // We want to load only those log type that are queried.
    uint32_t classmask = LOGCLASS_ALL;
    query->optimizeBitmask("class", &classmask);
    if (classmask == 0) {
        return;
    }

    /* This code start with the oldest log entries. I'm going
       to change this and start with the newest. That way,
       the Limit: header produces more reasonable results. */

    /* NEW CODE - NEWEST FIRST */
    _logfiles_t::iterator it;
    it = _log_cache->logfiles()->end();  // it now points beyond last log file
    --it;  // switch to last logfile (we have at least one)

    // Now find newest log where 'until' is contained. The problem
    // here: For each logfile we only know the time of the *first* entry,
    // not that of the last.
    while (it != _log_cache->logfiles()->begin() &&
           it->first > until) {  // while logfiles are too new...
        --it;                    // go back in history
    }
    if (it->first > until) {
        return;  // all logfiles are too new
    }

    while (true) {
        Logfile *log = it->second;
        if (!log->answerQueryReverse(query, _log_cache, since, until,
                                     classmask)) {
            break;  // end of time range found
        }
        if (it == _log_cache->logfiles()->begin()) {
            break;  // this was the oldest one
        }
        --it;
    }
}

bool TableLog::isAuthorized(contact *ctc, void *data) {
    LogEntry *entry = static_cast<LogEntry *>(data);
    service *svc = entry->_service;
    host *hst = entry->_host;

    if ((hst != nullptr) || (svc != nullptr)) {
        return static_cast<int>(is_authorized_for(ctc, hst, svc)) != 0;
        // suppress entries for messages that belong to
        // hosts that do not exist anymore.
    }
    return !(entry->_logclass == LOGCLASS_ALERT ||
             entry->_logclass == LOGCLASS_NOTIFICATION ||
             entry->_logclass == LOGCLASS_PASSIVECHECK ||
             entry->_logclass == LOGCLASS_STATE);
}

Column *TableLog::column(const char *colname) {
    // First try to find column in the usual way
    Column *col = Table::column(colname);
    if (col != nullptr) {
        return col;
    }

    // Now try with prefix "current_", since our joined
    // tables have this prefix in order to make clear that
    // we access current and not historic data and in order
    // to prevent mixing up historic and current fields with
    // the same name.
    string with_current = string("current_") + colname;
    return Table::column(with_current.c_str());
}
